(function($) {

	"use strict";

})(jQuery);